<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1">
   	
    	<meta name="description" content="MAGS Rocket League Group">
    	<meta name="keywords" content="HTML,CSS,XML,JavaScript">
    	<meta name="author" content="Praful Patel">
   
    	<title>Page Title</title>
   
    	<!-- link to css goes here -->
   	 	<link href="css/magsrlteam.css" rel="stylesheet">
		<!-- Font Link goes here-->
		
   
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300;400&display=swap" rel="stylesheet">
	</head>

<body>
	<div class="wrapper">
		
		
		<header>
			 
			<a href="index.php"> <img src="img/header.png" alt="Mags Rocket League Banner" height="200" class="center" /></a>
		</header>
		
		
		
		<nav>
			
			<a class="dropbtn" href="index.php">Home</a> |
			
			<div class="dropdown">
				<a class="dropbtn" href="#">Members <span class="littlearrow">&#9660;</span></a>
				<div class="dropdown-content">
					<a href="applecrash.php">AppleCrash</a>
					<a href="decayyn.php">Decayyn</a>
				</div> <!--/ end of dropdown-content-->
			</div> <!-- / Dropdown -->
			
			<!-- New Dropdown!-->
			|
			<div class="dropdown">
				<a class="dropbtn" href="#">Tournaments <span class="littlearrow">&#9660;</span></a>
				<div class="dropdown-content">
					<a href="meta.php">Meta Esports</a>
					<a href="waikato.php">Waikato Tournament</a>
				</div>
			</div>
			|
			
			<a class="dropbtn" href="register.php">Register</a> 
			
		</nav>
	</div>