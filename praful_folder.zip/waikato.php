<?php include "Nav.php"; ?>
		<div class="wrapper">
		<main class="box">
	
			<h2>Waikato Tournament</h2>
			
			<p>
				The Waikato Tournament is hosted by the University of Waikato and is open to all highschools around NZ.<br />
				This is a new tournament only just been orginized this season and has a large amount of teams that have register for it. <br />
				This tournament will be a fun experience from beginners all the way to nearly gone pro's. <br />
				So far the tournament is free however we do not know if it will continue to stay like this. <br />
				
			</p>
			
</main>	
		
		<aside class="box">
				<script>
					function getVote(int) {
						var xmlhttp=new XMLHttpRequest();
						xmlhttp.onreadystatechange=function() {
							if (this.readyState==4 && this.status==200) {
								document.getElementById("poll").innerHTML=this.responseText;
							}
						}
						xmlhttp.open("GET","polls/waikatopoll.php?vote="+int,true);
						xmlhttp.send();
					}
				</script>
			
				<div id="poll">
					<h3> Has Musty gone pro?</h3>
					<form>
						No <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
						Yes <input type="radio" name="vote" value="1" onclick="getVote(this.value)">
					</form>
				</div>
			
	</aside>


	<?php include "Footer.php"; ?>