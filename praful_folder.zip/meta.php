<?php include "Nav.php"; ?>
		<div class="wrapper">
		<main class="box">
	
			<h2>META Tournament</h2>
			
			<p>
				The Waikato Tournament is hosted by META Esports and is available for all highschools in OCE.<br />
				This is a new tournament has been going on for a while now and they also do a bunch of other games. <br />
				This tournament will be a very big leap as it is very orginized. <br />
				The tournament used to be free however due to COVID they got some of their funding cut, causing them to know have a registration fee. <br />
				
			</p>
			
</main>	
		
		<aside class="box">
				<script>
					function getVote(int) {
						var xmlhttp=new XMLHttpRequest();
						xmlhttp.onreadystatechange=function() {
							if (this.readyState==4 && this.status==200) {
								document.getElementById("poll").innerHTML=this.responseText;
							}
						}
						xmlhttp.open("GET","polls/metapoll.php?vote="+int,true);
						xmlhttp.send();
					}
				</script>
			
				<div id="poll">
					<h3> How many polls are there on this website?</h3>
					<form>
						6 polls <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
						8 polls <input type="radio" name="vote" value="1" onclick="getVote(this.value)">
					</form>
				</div>
			
	</aside>


	<?php include "Footer.php"; ?>