<?php include "Nav.php"; ?>
		<div class="wrapper">
		<main class="box">
	
			<h2>Decayyn</h2>
			
			<p>
				Praful Patel known as Decayyn is a promising newcomer climbing the ranks to prove himself worthy to create a career from Rocket League. <br />
				Looking up to some of the best, Decayyn knows the grind and is persevering to trying and climb the curve. <br />
				Here are his top three best clips.<br />
				<br />
				<br />
				<br />
			</p>
			
		
		
<!-- Slideshow container -->

<div class="slideshow-container">
  <!-- Full-width images with number and caption text -->
  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img src="img/decaynn1.jpg" alt="Image 1" style="width:100%">
    <div class="text">META Esports tournament game 1</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">2 / 3</div>
    <img src="img/decaynn2.jpg" alt="Image 2" style="width:100%">
    <div class="text">Training for Esports competition</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">3 / 3</div>
    <img src="img/decaynn3.jpg" alt="Image 3" style="width:100%">
    <div class="text">Qualifiers for Knockout Rounds</div>
  </div>

  <!-- Next and previous buttons -->
  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
<br>

<!-- The dots/circles -->
<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span>
  <span class="dot" onclick="currentSlide(2)"></span>
  <span class="dot" onclick="currentSlide(3)"></span>
</div>


<script>
	var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}
	
</script>
</main>	
		
		<aside class="box">
				<script>
					function getVote(int) {
						var xmlhttp=new XMLHttpRequest();
						xmlhttp.onreadystatechange=function() {
							if (this.readyState==4 && this.status==200) {
								document.getElementById("poll").innerHTML=this.responseText;
							}
						}
						xmlhttp.open("GET","polls/decayynpoll.php?vote="+int,true);
						xmlhttp.send();
					}
				</script>
			
				<div id="poll">
					<h3> Does this Decayyn noob want to go pro?</h3>
					<form>
						Yes <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
						No <input type="radio" name="vote" value="1" onclick="getVote(this.value)">
					</form>
				</div>
			
	</aside>


	<?php include "Footer.php"; ?>