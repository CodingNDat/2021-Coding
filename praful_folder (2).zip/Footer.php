		<footer>
			<img src="img/footer.png" alt="Footer" width="1080"  class="center" />
		</footer>
</div>
</body>
</html>