<?php include "Nav.php"; ?>
		
	<div class="wrapper">
		<main class="box">
	
			<h2>Register</h2>
			
			<p>
				Registrations for the group are always open feel free to sign up and let us know what tournaments you would like to participate in. <br />
				As more and more tournaments are being hosted we will let you know with some costing and other being free. <br />
				All tournaments that are announced will require you to represent MAGS as they are high school tournaments however on our MAGS Discord we will have a page with server you can join which host public tournaments, not requiring you to represent us<br />
				The form consists of basic questions as well as contact details so we can add you to our group pages<br />
				<br />
				<br />	
			</p>
			
			<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSf_goZ_MuZw31Z9Ll9TnV2MAmjxDUYqAImZJ1p5lqObtHob2Q/viewform?embedded=true"  height="2326" ></iframe>
			
			</main>	
		
		<aside class="box">
				<script>
					function getVote(int) {
						var xmlhttp=new XMLHttpRequest();
						xmlhttp.onreadystatechange=function() {
							if (this.readyState==4 && this.status==200) {
								document.getElementById("poll").innerHTML=this.responseText;
							}
						}
						xmlhttp.open("GET","polls/registerpoll.php?vote="+int,true);
						xmlhttp.send();
					}
				</script>
			
				<div id="poll">
					<h3>Did Grand Champ used to be the highest rank in rocket league? </h3>
					<form>
						Yes: <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
						No: <input type="radio" name="vote" value="1" onclick="getVote(this.value)">
					</form>
				</div>
			
	</aside>


	<?php include "Footer.php"; ?>