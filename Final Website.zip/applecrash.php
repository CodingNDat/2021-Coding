<?php include "Nav.php"; ?>
		<div class="wrapper">
		<main class="box">
	
			<h2>Applecrash</h2>
			
			<p>
				Luka Jerimich known as Apple Crash is our greatest player. An SSL prodigy with great talent set us up with promise for this year, Bringing home the Oceania Highschool cup home last year.<br />
				Former playing for the org Forbidden Gaming, also used to play for Apples are sour but just recently has become a part of SAD Gaming. <br />
				Here are 3 of his bests clips he has hit.
			</p>
			
		
		
<!-- Slideshow container -->

<div class="slideshow-container">
  <!-- Full-width images with number and caption text -->
  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img src="img/applecrash1.jpg" alt="Image 1" style="width:100%">
    <div class="text">MAGS META Tournament Match</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">2 / 3</div>
    <img src="img/applecrash2.jpg" alt="Image 2" style="width:100%">
    <div class="text">Apple Crash Pro Game</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">3 / 3</div>
    <img src="img/applecrash3.jpg" alt="Image 3" style="width:100%">
    <div class="text">Forbidden vs GG</div>
  </div>

  <!-- Next and previous buttons -->
  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
<br>

<!-- The dots/circles -->
<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span>
  <span class="dot" onclick="currentSlide(2)"></span>
  <span class="dot" onclick="currentSlide(3)"></span>
</div>


<script>
	var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}
	
</script>
</main>	
		
		<aside class="box">
				<script>
					function getVote(int) {
						var xmlhttp=new XMLHttpRequest();
						xmlhttp.onreadystatechange=function() {
							if (this.readyState==4 && this.status==200) {
								document.getElementById("poll").innerHTML=this.responseText;
							}
						}
						xmlhttp.open("GET","polls/applecrashpoll.php?vote="+int,true);
						xmlhttp.send();
					}
				</script>
			
				<div id="poll">
					<h3> How many hours does AppleCrash have in the game?</h3>
					<form>
						2000+ <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
						3000+ <input type="radio" name="vote" value="1" onclick="getVote(this.value)">
					</form>
				</div>
			
	</aside>


	<?php include "Footer.php"; ?>