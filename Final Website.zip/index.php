<?php include "Nav.php"; ?>
		<div class="wrapper">
		<main class="box">
	
			<h2>Welcome!!!</h2>
			
			<p>
				Welcome to the MAGS Rocket League Group Website!!! <br />
				This website is for those interested in the Rocket League group at mags who are or looking to participate in the E-Sport and see what mags has to offer for it. <br />
				For those who are new Rocket League is a game like no other where you jump into a vast online experience of rocket powered cars and football. <br />
				Two teams battle it out like regular football to see who can come out on top. <br />
				<br />
				Rocket League is a game with a big skill curve meaning progression is visable for those who like to see improvement straight away. <br />
				There are many opportunities here at MAGS for both beginners and veterans. Especially that now Rocket League has gone free to play meaning anyone can join! <br />
				<br />
				<br />
				<br />
			</p>
			
		
		
<!-- Slideshow container -->

<div class="slideshow-container">
  <!-- Full-width images with number and caption text -->
  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img src="img/img1.jpg" alt="Image 1" style="width:100%">
    <div class="text">Season 8 RLCS Venue</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">2 / 3</div>
    <img src="img/img2.jpg" alt="Image 2" style="width:100%">
    <div class="text">RLCS Grand Finals Venue</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">3 / 3</div>
    <img src="img/img3.jpg" alt="Image 3" style="width:100%">
    <div class="text">Qualifiers for RLCS Knockout Rounds</div>
  </div>

  <!-- Next and previous buttons -->
  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
<br>

<!-- The dots/circles -->
<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span>
  <span class="dot" onclick="currentSlide(2)"></span>
  <span class="dot" onclick="currentSlide(3)"></span>
</div>


<script>
	var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}
	
</script>
</main>	
		
		<aside class="box">
			<p>
				Throughout the website I have created a quiz in form of a poll about Rocket League. Once answered yes or no you will be able to see the percentage of people that clicked either yes or no and I will also let you know whether you got it correct or incorrect. <br />
				First Question: <br />
			</p>
		
				<script>
					function getVote(int) {
						var xmlhttp=new XMLHttpRequest();
						xmlhttp.onreadystatechange=function() {
							if (this.readyState==4 && this.status==200) {
								document.getElementById("poll").innerHTML=this.responseText;
							}
						}
						xmlhttp.open("GET","polls/homepoll.php?vote="+int,true);
						xmlhttp.send();
					}
				</script>
			
				<div id="poll">
					<h3>Has Psyonix been bought by epic games? </h3>
					<form>
						Yes: <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
						No: <input type="radio" name="vote" value="1" onclick="getVote(this.value)">
					</form>
				</div>
			
	</aside>


	<?php include "Footer.php"; ?>